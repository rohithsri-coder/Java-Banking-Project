package project.java;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class Account {
    private int accountNumber;
    private int userId;
    private String accountType; 
    private BigDecimal balance;
    private String status;      
    private Timestamp createdAt;

    public Account() {}

    public Account(int accountNumber, int userId, String accountType, BigDecimal balance, String status, Timestamp createdAt) {
        this.accountNumber = accountNumber;
        this.userId = userId;
        this.accountType = accountType;
        this.balance = balance;
        this.status = status;
        this.createdAt = createdAt;
    }

 
    public int getAccountNumber() { 
    	return accountNumber; 
    }
    public void setAccountNumber(int accountNumber) { 
    	this.accountNumber = accountNumber; 
    }

    public int getUserId() { 
    	return userId; 
    }
    public void setUserId(int userId) { 
    	this.userId = userId; 
    }

    public String getAccountType() { 
    	return accountType; 
    }
    public void setAccountType(String accountType) { 
    	this.accountType = accountType; 
    }

    public BigDecimal getBalance() { 
    	return balance; 
    }
    public void setBalance(BigDecimal balance) { 
    	this.balance = balance; 
    }

    public String getStatus() { 
    	return status; 
    }
    public void setStatus(String status) { 
    	this.status = status; 
    }

    public Timestamp getCreatedAt() { 
    	return createdAt; 
    }
    public void setCreatedAt(Timestamp createdAt) { 
    	this.createdAt = createdAt; 
    }
}
