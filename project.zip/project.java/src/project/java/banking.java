package project.java;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Banking {

    private static final String URL = "jdbc:mysql://localhost:3306/bank_db";
    private static final String USER = "root";
    private static final String PASSWORD = "password";

    public boolean transferFunds(int senderAccountId, int receiverAccountId, double amount) {
        String deductQuery = "UPDATE accounts SET balance = balance - ? WHERE account_number = ? AND balance >= ?";
        String addQuery = "UPDATE accounts SET balance = balance + ? WHERE account_number = ?";
        String logQuery = "INSERT INTO transactions (from_account, to_account, amount, type) VALUES (?, ?, ?, 'TRANSFER')";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            
            conn.setAutoCommit(false);

            try (PreparedStatement deductStmt = conn.prepareStatement(deductQuery);
                 PreparedStatement addStmt = conn.prepareStatement(addQuery);
                 PreparedStatement logStmt = conn.prepareStatement(logQuery)) {

             
                deductStmt.setDouble(1, amount);
                deductStmt.setInt(2, senderAccountId);
                deductStmt.setDouble(3, amount);
                int rowsUpdatedSender = deductStmt.executeUpdate();

                if (rowsUpdatedSender == 0) {
                    throw new SQLException("Insufficient balance");
                }

             
                addStmt.setDouble(1, amount);
                addStmt.setInt(2, receiverAccountId);
                int rowsUpdatedReceiver = addStmt.executeUpdate();

                if (rowsUpdatedReceiver == 0) {
                    throw new SQLException("Invalid receiver account.");
                }

              
                logStmt.setInt(1, senderAccountId);
                logStmt.setInt(2, receiverAccountId);
                logStmt.setDouble(3, amount);
                logStmt.executeUpdate();

             
                conn.commit();
                System.out.println("Transaction successful!");
                return true;

            } catch (SQLException e) {
        
                conn.rollback();
                System.err.println("Transaction failed and rolled back: " + e.getMessage());
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
