package project.java;

import com.bank.model.Transaction;
import com.bank.util.DatabaseConnection;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TransactionDAO {
	
	private final AccountDAO accountDAO = new AccountDAO();

	    
	    public boolean logTransaction(Connection conn, Integer fromAcc, Integer toAcc, BigDecimal amount, String type, String status) throws SQLException {
	        String sql = "INSERT INTO transactions (from_account, to_account, amount, type, status) VALUES (?, ?, ?, ?, ?)";
	        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
	            if (fromAcc != null) pstmt.setInt(1, fromAcc);
	            else pstmt.setNull(1, Types.INTEGER);

	            if (toAcc != null) pstmt.setInt(2, toAcc);
	            else pstmt.setNull(2, Types.INTEGER);

	            pstmt.setBigDecimal(3, amount);
	            pstmt.setString(4, type);
	            pstmt.setString(5, status);

	            return pstmt.executeUpdate() > 0;
	        }
	    }

	 
	    public boolean executeTransfer(int fromAcc, int toAcc, BigDecimal amount) throws SQLException {
	        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
	            throw new IllegalArgumentException("Transfer amount must be positive.");
	        }

	        Connection conn = null;
	        try {
	            conn = DatabaseConnection.getConnection();
	            conn.setAutoCommit(false); 

	       
	            boolean deducted = accountDAO.updateBalance(conn, fromAcc, amount.negate());
	            if (!deducted) {
	                throw new SQLException("Debit failed. Check sender account balance or status.");
	            }

	        
	            boolean credited = accountDAO.updateBalance(conn, toAcc, amount);
	            if (!credited) {
	                throw new SQLException("Credit failed. Receiver account non-existent or inactive.");
	            }

	     
	            logTransaction(conn, fromAcc, toAcc, amount, "TRANSFER", "SUCCESS");

	            conn.commit();
	            return true;

	        } catch (SQLException e) {
	            if (conn != null) {
	                try {
	                    conn.rollback(); 
	                } catch (SQLException rollbackEx) {
	                    rollbackEx.printStackTrace();
	                }
	            }
	            throw e;
	        } finally {
	            if (conn != null) {
	                conn.setAutoCommit(true);
	                conn.close();
	            }
	        }
	    }

	   
	    public boolean executeDeposit(int toAcc, BigDecimal amount) throws SQLException {
	        Connection conn = null;
	        try {
	            conn = DatabaseConnection.getConnection();
	            conn.setAutoCommit(false);

	            boolean credited = accountDAO.updateBalance(conn, toAcc, amount);
	            if (!credited) {
	                throw new SQLException("Deposit failed. Inactive or invalid account.");
	            }

	            logTransaction(conn, null, toAcc, amount, "DEPOSIT", "SUCCESS");

	            conn.commit();
	            return true;
	        } catch (SQLException e) {
	            if (conn != null) conn.rollback();
	            throw e;
	        } finally {
	            if (conn != null) {
	                conn.setAutoCommit(true);
	                conn.close();
	            }
	        }
	    }

	    
	    public List<Transaction> getTransactionHistory(int accountNumber) throws SQLException {
	        List<Transaction> list = new ArrayList<>();
	        String sql = "SELECT * FROM transactions WHERE from_account = ? OR to_account = ? ORDER BY timestamp DESC";

	        try (Connection conn = DatabaseConnection.getConnection();
	             PreparedStatement pstmt = conn.prepareStatement(sql)) {

	            pstmt.setInt(1, accountNumber);
	            pstmt.setInt(2, accountNumber);

	            try (ResultSet rs = pstmt.executeQuery()) {
	                while (rs.next()) {
	                    Transaction tx = new Transaction(
	                            rs.getLong("transaction_id"),
	                            (Integer) rs.getObject("from_account"),
	                            (Integer) rs.getObject("to_account"),
	                            rs.getBigDecimal("amount"),
	                            rs.getString("type"),
	                            rs.getString("status"),
	                            rs.getTimestamp("timestamp")
	                    );
	                    list.add(tx);
	                }
	            }
	        }
	        return list;
	    }
	}

}
