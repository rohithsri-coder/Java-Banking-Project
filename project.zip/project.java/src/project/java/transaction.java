package project.java;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class transaction {
	private long transactionId;
	private Integer fromAccount; 
	private Integer toAccount;  
	private BigDecimal amount;
    private String type;         
	private String status;       
	private Timestamp timestamp;

	    public transaction() {}

	    public transaction(long transactionId, Integer fromAccount, Integer toAccount, BigDecimal amount, String type, String status, Timestamp timestamp) {
	        this.transactionId = transactionId;
	        this.fromAccount = fromAccount;
	        this.toAccount = toAccount;
	        this.amount = amount;
	        this.type = type;
	        this.status = status;
	        this.timestamp = timestamp;
	    }

	    public long getTransactionId() { 
	    	return transactionId; 
	    }
	    public void setTransactionId(long transactionId) { 
	    	this.transactionId = transactionId; 
	    }

	    public Integer getFromAccount() { 
	    	return fromAccount; 
	    }
	    public void setFromAccount(Integer fromAccount) { 
	    	this.fromAccount = fromAccount; 
	    }

	    public Integer getToAccount() { 
	    	return toAccount; 
	    }
	    public void setToAccount(Integer toAccount) { 
	    	this.toAccount = toAccount; 
	    }

	    public BigDecimal getAmount() { 
	    	return amount; 
	    }
	    public void setAmount(BigDecimal amount) { 
	    	this.amount = amount; 
	    }

	    public String getType() { 
	    	return type; 
	    }
	    public void setType(String type) { 
	    	this.type = type; 
	    }

	    public String getStatus() { 
	    	return status; 
	    }
	    public void setStatus(String status) { 
	    	this.status = status; 
	    }

	    public Timestamp getTimestamp() { 
	    	return timestamp; 
	    }
	    public void setTimestamp(Timestamp timestamp) { 
	    	this.timestamp = timestamp;
	    }
}