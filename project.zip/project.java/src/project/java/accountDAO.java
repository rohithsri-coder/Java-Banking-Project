package project.java;

import com.bank.model.Account;
import com.bank.util.DatabaseConnection;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class AccountDAO {

	    public boolean createAccount(Account account) throws SQLException {
	        String sql = "INSERT INTO accounts (user_id, account_type, balance) VALUES (?, ?, ?)";
	        try (Connection conn = DatabaseConnection.getConnection();
	             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
	            
	            pstmt.setInt(1, account.getUserId());
	            pstmt.setString(2, account.getAccountType());
	            pstmt.setBigDecimal(3, account.getBalance() != null ? account.getBalance() : BigDecimal.ZERO);

	            int affectedRows = pstmt.executeUpdate();
	            if (affectedRows > 0) {
	                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
	                    if (generatedKeys.next()) {
	                        account.setAccountNumber(generatedKeys.getInt(1));
	                    }
	                }
	                return true;
	            }
	        }
	        return false;
	    }

	    public Optional<Account> getAccountByNumber(int accountNumber) throws SQLException {
	        String sql = "SELECT * FROM accounts WHERE account_number = ?";
	        try (Connection conn = DatabaseConnection.getConnection();
	             PreparedStatement pstmt = conn.prepareStatement(sql)) {

	            pstmt.setInt(1, accountNumber);
	            try (ResultSet rs = pstmt.executeQuery()) {
	                if (rs.next()) {
	                    return Optional.of(mapResultSetToAccount(rs));
	                }
	            }
	        }
	        return Optional.empty();
	    }

	    public List<Account> getAccountsByUserId(int userId) throws SQLException {
	        List<Account> accounts = new ArrayList<>();
	        String sql = "SELECT * FROM accounts WHERE user_id = ?";
	        try (Connection conn = DatabaseConnection.getConnection();
	             PreparedStatement pstmt = conn.prepareStatement(sql)) {

	            pstmt.setInt(1, userId);
	            try (ResultSet rs = pstmt.executeQuery()) {
	                while (rs.next()) {
	                    accounts.add(mapResultSetToAccount(rs));
	                }
	            }
	        }
	        return accounts;
	    }

	    public boolean updateStatus(int accountNumber, String newStatus) throws SQLException {
	        String sql = "UPDATE accounts SET status = ? WHERE account_number = ?";
	        try (Connection conn = DatabaseConnection.getConnection();
	             PreparedStatement pstmt = conn.prepareStatement(sql)) {

	            pstmt.setString(1, newStatus);
	            pstmt.setInt(2, accountNumber);
	            return pstmt.executeUpdate() > 0;
	        }
	    }


	    public boolean updateBalance(Connection conn, int accountNumber, BigDecimal amountDelta) throws SQLException {
	        String sql = "UPDATE accounts SET balance = balance + ? WHERE account_number = ? AND status = 'ACTIVE' AND (balance + ?) >= 0";
	        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
	            pstmt.setBigDecimal(1, amountDelta);
	            pstmt.setInt(2, accountNumber);
	            pstmt.setBigDecimal(3, amountDelta);
	            return pstmt.executeUpdate() > 0;
	        }
	    }

	    private Account mapResultSetToAccount(ResultSet rs) throws SQLException {
	        return new Account(
	                rs.getInt("account_number"),
	                rs.getInt("user_id"),
	                rs.getString("account_type"),
	                rs.getBigDecimal("balance"),
	                rs.getString("status"),
	                rs.getTimestamp("created_at")
	        );
	    }
	}
}
